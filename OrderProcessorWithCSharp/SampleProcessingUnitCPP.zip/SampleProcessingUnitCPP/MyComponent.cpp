#include "pch.h"
#include "MyComponentHeader.h"

MyComponentHeader::MyComponentHeader()
{
}

