#pragma once
#include "pch.h"
#include <windows.h>

using namespace System;
using namespace GigaSpaces::Core;
using namespace GigaSpaces::Core::Metadata;
using namespace GigaSpaces::XAP::ProcessingUnit::Containers::BasicContainer;
using namespace GigaSpaces::Core::XAP::ProcessingUnit::Containers::BasicContainer;


[BasicProcessingUnitComponent]
ref class MyComponentHeader
{
public:
    MyComponentHeader();

    [PostPrimaryAttribute]
    void StartMonitoring(ISpaceProxy^ proxy)
    {
        Console::WriteLine(">>>>> MyComponentHeader post primary -> startmonitoring " + proxy->Name);
    }

};